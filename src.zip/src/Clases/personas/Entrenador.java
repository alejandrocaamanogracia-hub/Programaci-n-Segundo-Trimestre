package Clases.personas;

public class Entrenador extends Persona{

    public Entrenador(){}

    public Entrenador(String nombre, int edad, String personalidad){
        super(nombre, edad, personalidad);
    }

}
